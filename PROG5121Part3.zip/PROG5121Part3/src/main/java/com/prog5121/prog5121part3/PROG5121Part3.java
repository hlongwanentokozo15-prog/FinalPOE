/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.prog5121.prog5121part3;

import java.util.Scanner;

/**
 * PROG5121 - Part 3
 * Store Data and Display Task Report
 * Author: NTOKOZO
 * 
 * Demonstrates:
 * - Parallel arrays
 * - Populating arrays with test data
 * - Generating message hashes
 * - Menu-driven features (6 options)
 * - Maintaining array alignment when deleting
 * - Producing formatted reports
 */
public class PROG5121Part3 {

    // === Parallel Arrays ===
    static String[] messageIDs = new String[10];        // Unique IDs
    static String[] recipientNumbers = new String[10];  // Recipients
    static String[] messages = new String[10];          // Message text
    static String[] messageHashes = new String[10];     // Hashes
    static String[] flags = new String[10];             // Sent / Disregard / Stored
    static int count = 0;                               // Current message count

    public static void main(String[] args) {
        // Step 1: Populate arrays with 5 test messages
        loadTestData();

        // Step 2: Run interactive menu
        storedMessagesMenu();
    }

    // === Load Test Data (Part 3 requirement) ===
    public static void loadTestData() {
        // Message 1
        messageIDs[0] = "0000000001";
        recipientNumbers[0] = "+27834557896";
        messages[0] = "Did you get the cake?";
        flags[0] = "Sent";
        messageHashes[0] = createMessageHash(messageIDs[0], messages[0]);
        count++;

        // Message 2
        messageIDs[1] = "0000000002";
        recipientNumbers[1] = "0838884567";
        messages[1] = "It is dinner time!";
        flags[1] = "Sent";
        messageHashes[1] = createMessageHash(messageIDs[1], messages[1]);
        count++;

        // Message 3
        messageIDs[2] = "0000000003";
        recipientNumbers[2] = "+27834484567";
        messages[2] = "Yohoooo, I am at your gate.";
        flags[2] = "Disregard";
        messageHashes[2] = createMessageHash(messageIDs[2], messages[2]);
        count++;

        // Message 4
        messageIDs[3] = "0000000004";
        recipientNumbers[3] = "+27838884567";
        messages[3] = "Where are you? You are late! I have asked you to be on time.";
        flags[3] = "Sent";
        messageHashes[3] = createMessageHash(messageIDs[3], messages[3]);
        count++;

        // Message 5
        messageIDs[4] = "0000000005";
        recipientNumbers[4] = "+27838884567";
        messages[4] = "Ok, I am leaving without you.";
        flags[4] = "Stored";
        messageHashes[4] = createMessageHash(messageIDs[4], messages[4]);
        count++;
    }

    // === Hash Generator ===
    public static String createMessageHash(String id, String msg) {
        String[] words = msg.trim().split("\\s+");
        String first = words[0].toUpperCase();
        String last = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "").toUpperCase();
        return id.substring(0,2) + ":" + first + last;
    }

    // === Menu ===
    public static void storedMessagesMenu() {
        Scanner sc = new Scanner(System.in);
        int choice;
        do {
            System.out.println("\n========== STORED MESSAGES MENU ==========");
            System.out.println("1. Display sender & recipient");
            System.out.println("2. Display longest message");
            System.out.println("3. Search by Message ID");
            System.out.println("4. Search by Recipient");
            System.out.println("5. Delete by Hash");
            System.out.println("6. Display full report");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch(choice) {
                case 1: displaySenderRecipient(); break;
                case 2: displayLongestMessage(); break;
                case 3: searchByMessageID(sc); break;
                case 4: searchByRecipient(sc); break;
                case 5: deleteByHash(sc); break;
                case 6: displayReport(); break;
                case 0: System.out.println("Exiting QuickChat. Goodbye!"); break;
                default: System.out.println("Invalid choice.");
            }
        } while(choice != 0);
        sc.close();
    }

    // === Feature 1: Display sender & recipient ===
    public static void displaySenderRecipient() {
        System.out.println("\n--- Sender & Recipient ---");
        for (int i = 0; i < count; i++) {
            System.out.println("Message ID: " + messageIDs[i] +
                               " | Recipient: " + recipientNumbers[i]);
        }
    }

    // === Feature 2: Display longest message ===
    public static void displayLongestMessage() {
        String longest = "";
        for (int i = 0; i < count; i++) {
            if (messages[i].length() > longest.length()) longest = messages[i];
        }
        System.out.println("\nLongest message: " + longest);
    }

    // === Feature 3: Search by Message ID ===
    public static void searchByMessageID(Scanner sc) {
        System.out.print("Enter Message ID: ");
        String id = sc.nextLine();
        for (int i = 0; i < count; i++) {
            if (messageIDs[i].equals(id)) {
                System.out.println("Recipient: " + recipientNumbers[i]);
                System.out.println("Message: " + messages[i]);
                return;
            }
        }
        System.out.println("Message ID not found.");
    }

    // === Feature 4: Search by Recipient ===
    public static void searchByRecipient(Scanner sc) {
        System.out.print("Enter Recipient: ");
        String rec = sc.nextLine();
        boolean found = false;
        for (int i = 0; i < count; i++) {
            if (recipientNumbers[i].equals(rec)) {
                System.out.println("Message: " + messages[i]);
                found = true;
            }
        }
        if (!found) System.out.println("No messages found for this recipient.");
    }

    // === Feature 5: Delete by Hash ===
    public static void deleteByHash(Scanner sc) {
        System.out.print("Enter Message Hash: ");
        String hash = sc.nextLine();
        for (int i = 0; i < count; i++) {
            if (messageHashes[i].equals(hash)) {
                System.out.println("Message: \"" + messages[i] + "\" deleted.");
                // Shift arrays left to maintain alignment
                for (int j = i; j < count-1; j++) {
                    messageIDs[j] = messageIDs[j+1];
                    recipientNumbers[j] = recipientNumbers[j+1];
                    messages[j] = messages[j+1];
                    messageHashes[j] = messageHashes[j+1];
                    flags[j] = flags[j+1];
                }
                count--;
                return;
            }
        }
        System.out.println("Hash not found.");
    }

    // === Feature 6: Display full report ===
    public static void displayReport() {
        System.out.println("\n========== MESSAGE REPORT ==========");
        for (int i = 0; i < count; i++) {
            System.out.println("Message Hash: " + messageHashes[i]);
            System.out.println("Recipient: " + recipientNumbers[i]);
            System.out.println("Message: " + messages[i]);
            System.out.println("Flag: " + flags[i]);
            System.out.println("---------------------------");
        }
    }
}


