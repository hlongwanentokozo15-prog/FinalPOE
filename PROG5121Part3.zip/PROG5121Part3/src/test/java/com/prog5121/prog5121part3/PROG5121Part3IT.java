/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.prog5121.prog5121part3;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for PROG5121Part3
 * Author: NTOKOZO
 * 
 * Tests the core features:
 * - Loading test data
 * - Hash generation
 * - Longest message detection
 * - Searching by ID and recipient
 * - Deleting by hash
 * - Report generation
 */
public class PROG5121Part3IT {

    // === Test 1: Load Test Data ===
    @Test
    public void testLoadTestData() {
        PROG5121Part3.count = 0;
        PROG5121Part3.loadTestData();
        assertEquals(5, PROG5121Part3.count, "Should load 5 messages");
        assertEquals("Did you get the cake?", PROG5121Part3.messages[0]);
    }

    // === Test 2: Hash Generation ===
    @Test
    public void testCreateMessageHash() {
        String hash = PROG5121Part3.createMessageHash("0000000001", "Did you get the cake?");
        assertEquals("00:DIDCAKE", hash, "Hash should match expected format");
    }

    // === Test 3: Longest Message ===
    @Test
    public void testLongestMessage() {
        PROG5121Part3.loadTestData();
        String longest = "";
        for (int i = 0; i < PROG5121Part3.count; i++) {
            if (PROG5121Part3.messages[i].length() > longest.length()) {
                longest = PROG5121Part3.messages[i];
            }
        }
        assertTrue(longest.contains("Where are you? You are late!"),
                   "Longest message should be the long one");
    }

    // === Test 4: Search by Message ID ===
    @Test
    public void testSearchByMessageID() {
        PROG5121Part3.loadTestData();
        String id = "0000000002";
        boolean found = false;
        for (int i = 0; i < PROG5121Part3.count; i++) {
            if (PROG5121Part3.messageIDs[i].equals(id)) {
                found = true;
                assertEquals("It is dinner time!", PROG5121Part3.messages[i]);
            }
        }
        assertTrue(found, "Message ID should be found");
    }

    // === Test 5: Search by Recipient ===
    @Test
    public void testSearchByRecipient() {
        PROG5121Part3.loadTestData();
        String rec = "+27838884567";
        boolean found = false;
        for (int i = 0; i < PROG5121Part3.count; i++) {
            if (PROG5121Part3.recipientNumbers[i].equals(rec)) {
                found = true;
            }
        }
        assertTrue(found, "Recipient should be found");
    }

    // === Test 6: Delete by Hash ===
    @Test
    public void testDeleteByHash() {
        PROG5121Part3.loadTestData();
        int before = PROG5121Part3.count;
        String hash = PROG5121Part3.messageHashes[0]; // delete first message

        // simulate deletion
        for (int i = 0; i < PROG5121Part3.count; i++) {
            if (PROG5121Part3.messageHashes[i].equals(hash)) {
                for (int j = i; j < PROG5121Part3.count - 1; j++) {
                    PROG5121Part3.messageIDs[j] = PROG5121Part3.messageIDs[j+1];
                    PROG5121Part3.recipientNumbers[j] = PROG5121Part3.recipientNumbers[j+1];
                    PROG5121Part3.messages[j] = PROG5121Part3.messages[j+1];
                    PROG5121Part3.messageHashes[j] = PROG5121Part3.messageHashes[j+1];
                    PROG5121Part3.flags[j] = PROG5121Part3.flags[j+1];
                }
                PROG5121Part3.count--;
                break;
            }
        }

        assertEquals(before - 1, PROG5121Part3.count, "Count should decrease after deletion");
    }
}
